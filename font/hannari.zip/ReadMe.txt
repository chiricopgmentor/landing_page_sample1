----------------------
フォントについて
----------------------

はんなり明朝は以下の派生フォントです。
「源ノ明朝 (Source Han Serif)」
Copyright(c)2017 Adobe Systems Incorporated (http://www.adobe.com/), with Reserved Font Name 'Source'.

 
----------------------
ライセンス
----------------------
このフォントのライセンスは、以下のライセンスに準じます。
SIL Open Font License 1.1

日本語訳
http://osdn.jp/projects/opensource/wiki/SIL_Open_Font_License_1.1